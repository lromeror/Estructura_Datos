package ggm.tallerarraylist_p01;

import tda.ArrayList;
import tda.List;

/**
 *
 * @author Admin
 */
public class Main {

    public static void main(String[] args) {

        // crear un ArrayList de enteros aquí
        // anañadir elementos al ArrayList creado
        // llamar al método toString aquí
        // probar los otros métodos solicitados e imprmir resultados

        // crear un ArrayList de Strings aquí
        // anañadir elementos al ArrayList creado
        // llamar al método toString aquí
        // probar los otros métodos solicitados e imprmir resultados

    }
}
