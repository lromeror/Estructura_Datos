package tests;

import java.util.Comparator;
import tda.Graph;
import tda.GraphAL;

public class Main {

    public static void main(String[] args) {

        Comparator<String> cmpVertices = (s1, s2) -> {
            return s1.compareTo(s2);
        };

        Comparator<String> cmpEdges = (s1, s2) -> {
            return s1.compareTo(s2);
        };
        Comparator<Integer> cmpVer = (s1, s2) -> {
            return s1-s2;
        };

        Graph<String, String> grafo = new GraphAL<>(true, cmpVertices, cmpEdges);

        grafo.addVertex("V1");
        grafo.addVertex("V2");
        grafo.addVertex("V3");
        grafo.addVertex("V4");
        grafo.addVertex("V5");
        grafo.addVertex("V6");

        grafo.connect("V1", "V2", 3, null);
        grafo.connect("V1", "V3", 4, null);
        grafo.connect("V1", "V5", 8, null);
        grafo.connect("V2", "V5", 5, null);
        grafo.connect("V3", "V5", 3, null);
        grafo.connect("V5", "V4", 7, null);
        grafo.connect("V5", "V6", 3, null);
        grafo.connect("V6", "V4", 2, null);

        System.out.println(grafo);
        System.out.println("");
        System.out.println(grafo.breadthTraversal("V1"));
        System.out.println("");
        System.out.println(grafo.depthTraversal("V6"));
        System.out.println("");
        
        //Grafo No dirigido
        Graph<String, String> grafo2 = new GraphAL<>(false, cmpVertices, cmpEdges);
        grafo2.addVertex("A");
        grafo2.addVertex("B");
        grafo2.addVertex("C");
        grafo2.addVertex("D");
        grafo2.addVertex("E");

        grafo2.connect("A", "B", 3, null);
        grafo2.connect("A", "D", 4, null);
        grafo2.connect("C", "E", 8, null);
        grafo2.connect("D", "C", 5, null);

        
        System.out.println(grafo2);
        System.out.println("");
        System.out.println(grafo2.breadthTraversal("A"));
        System.out.println("");
        System.out.println(grafo2.depthTraversal("A"));
        System.out.println("");
        System.out.println(grafo2);
        System.out.println(grafo2.conexoNoDirigido());
        System.out.println(grafo2.compConexas());
        System.out.println("");

        Graph<String, String> grafo3 = new GraphAL<>(false, cmpVertices, cmpEdges);
        grafo3.addVertex("A");
        grafo3.addVertex("B");
        grafo3.addVertex("C");
        grafo3.addVertex("D");
        grafo3.addVertex("E");
        
        grafo3.connect("A", "B", 3, null);
        grafo3.connect("C", "E", 8, null);
        grafo3.connect("C", "D", 5, null);
        
        System.out.println(grafo3);
        System.out.println("");
        System.out.println(grafo3.breadthTraversal("A"));
        System.out.println("");
        System.out.println(grafo3.depthTraversal("C"));
        System.out.println("");
        System.out.println(grafo3.conexoNoDirigido());
        System.out.println(grafo3.compConexas());
        System.out.println("");
        
        //Grafos Dirigidos
        Graph<String, String> grafo4 = new GraphAL<>(true, cmpVertices, cmpEdges);
        grafo4.addVertex("C");
        grafo4.addVertex("F");
        grafo4.addVertex("H");
        grafo4.addVertex("B");
        grafo4.addVertex("S");
        
        grafo4.connect("F","S");
        grafo4.connect("F","C");
        grafo4.connect("H","F");
        grafo4.connect("H","B");
        grafo4.connect("S","C");
        grafo4.connect("C","B");
        grafo4.connect("B","S");
        System.out.println(grafo4.breadthTraversal("F"));
   
        System.out.println(grafo4.fuertementeConexa());
        System.out.println("");
        
        Graph<Integer, String> grafo5 = new GraphAL<>(true, cmpVer, cmpEdges);
        grafo5.addVertex(4);
        grafo5.addVertex(5);
        grafo5.addVertex(6);
        grafo5.addVertex(8);
        
        System.out.println(grafo5.fuertementeConexa());     
    }
}
