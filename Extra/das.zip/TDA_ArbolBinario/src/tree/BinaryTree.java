package tree;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

public class BinaryTree<T> {

    private BinaryNode<T> root;

    public BinaryTree() {
        this.root = null;
    }

    public BinaryTree(BinaryNode<T> root) {
        this.root = root;
    }

    public BinaryTree(T content) {
        this.root = new BinaryNode<>(content);
    }

    public BinaryNode<T> getRoot() {
        return root;
    }

    public void setRoot(BinaryNode<T> root) {
        this.root = root;
    }

    public void setLeft(BinaryTree<T> tree) {
        this.root.setLeft(tree);
    }

    public void setRight(BinaryTree<T> tree) {
        this.root.setRight(tree);
    }

    public BinaryTree<T> getLeft() {
        return this.root.getLeft();
    }

    public BinaryTree<T> getRight() {
        return this.root.getRight();
    }

    public boolean isEmpty() {
        return this.root == null;
    }

    public boolean isLeaf() {
        return this.root.getLeft() == null && this.root.getRight() == null;
    }

    public int countLeavesRecursive() {
        if (this.isEmpty()) {
            return 0;
        } else if (this.isLeaf()) {
            return 1;
        } else {
            int leavesLeft = 0;
            int leavesRight = 0;
            if (this.root.getLeft() != null) {
                leavesLeft = this.root.getLeft().countLeavesRecursive();
            }
            if (this.root.getRight() != null) {
                leavesRight = this.root.getRight().countLeavesRecursive();
            }
            return leavesLeft + leavesRight;
        }
    }

    public int countLeavesIterative() {
        Stack<BinaryTree<T>> stack = new Stack();
        int count = 0;
        if (this.isEmpty()) {
            return count;
        } else {
            stack.push(this);
            while (!stack.empty()) {
                BinaryTree<T> subtree = stack.pop();
                if (subtree.root.getLeft() != null) {
                    stack.push(subtree.root.getLeft());
                }
                if (subtree.root.getRight() != null) {
                    stack.push(subtree.root.getRight());
                }
                if (subtree.isLeaf()) {
                    count++;
                }
            }
        }
        return count;
    }

    public BinaryNode<T> recursiveSearch(T content, Comparator<T> cmp) {
        if (this.isEmpty()) {
            return null;
        } else {
            if (cmp.compare(this.root.getContent(), content) == 0) {
                return this.root;
            } else {
                BinaryNode<T> tmp = null;
                if (this.root.getLeft() != null) {
                    tmp = this.root.getLeft().recursiveSearch(content, cmp);
                }
                if (tmp == null) {
                    if (this.root.getRight() != null) {
                        return this.root.getRight().recursiveSearch(content, cmp);
                    }
                }
                return tmp;
            }
        }
    }

    public int heightRecursive() {
        if (this.root == null) {
            return 0;
        } else if (this.isLeaf()) {
            return 1;
        } else {
            int altura = 0;
            if (this.root.getLeft() != null) {
                altura += this.root.getLeft().heightRecursive();
            }
            if (this.root.getRight() != null) {
                altura += this.root.getRight().heightRecursive();
            }
            return altura;
        }
    }

    public int heightIterative() {
        Stack<BinaryTree<T>> stack2 = new Stack();
        int altura = 0;
        if (this.isEmpty()) {
            return altura;
        } else {
            stack2.push(this);
            while (!stack2.empty()) {
                BinaryTree<T> subtree = stack2.pop();
                if (subtree.root.getLeft() != null) {
                    stack2.push(subtree.root.getLeft());
                }
                if (subtree.root.getRight() != null) {
                    stack2.push(subtree.root.getRight());
                }
                if (subtree.isLeaf()) {
                    altura++;
                }
            }
        }
        return altura;
    }


    public T getParentRecursive(BinaryNode<T> hijo, Comparator<T> cmp) {
        if (isEmpty() || isLeaf()) {
            return null;
        }
        T padre = null;
        boolean encontrado = false;
        if (!encontrado) {
            if (this.getLeft() != null) {
                if (cmp.compare(this.getLeft().getRoot(), hijo.getContent()) == 0) {
                    padre = this.getRoot();
                    encontrado = true;
                } else if (!encontrado) {
                    padre = this.getLeft().getParentRecursive(hijo, cmp);
                }
            }
            if (this.getRight() != null) {
                if (cmp.compare(this.getRight().getRoot(), hijo.getContent()) == 0) {
                    padre = this.getRoot();
                    encontrado = true;
                } else if (!encontrado) {
                    padre = this.getRight().getParentRecursive(hijo, cmp);
                }
            }
        }
        return padre;
    }

    public T getParentIterative(BinaryNode<T> hijo, Comparator<T> cmp) {
        if (isEmpty() || isLeaf()) {
            return null;
        }
        T padre = null;
        Stack<BinaryTree<T>> s = new Stack<>();
        s.push(this);
        while (!s.isEmpty()) {
            BinaryTree<T> arbol = s.pop();
            if (arbol.getLeft() != null) {
                if (cmp.compare(arbol.getLeft().getRoot(), hijo.getContent()) == 0) {
                    padre = arbol.getRoot();
                } else {
                    s.push(arbol.getLeft());
                }
            }
            if (arbol.getRight() != null) {
                if (cmp.compare(arbol.getRight().getRoot(), hijo.getContent()) == 0) {
                    padre = arbol.getRoot();
                } else {
                    s.push(arbol.getRight());
                }
            }
        }
        return padre;
    }

    public boolean isBSTRecursive(Comparator<T> cmp) {
        ArrayList<Boolean> bst = new ArrayList<>();
        if (!isLeaf()) {
            if (this.getLeft() != null) {
                bst.add(cmp.compare(this.getRoot(), this.getLeft().getRoot()) > 0);
                if (this.getLeft().getLeft() != null) {
                    bst.add(this.getLeft().isBSTRecursive(cmp));
                }
            }
            if (this.getRight() != null) {
                bst.add(cmp.compare(this.getRoot(), this.getRight().getRoot()) < 0);
                if (this.getRight().getRight() != null) {
                    bst.add(this.getRight().isBSTRecursive(cmp));
                }
            }
            return !bst.contains(false);
        }
        return false;
    }

    public boolean isBSTIterative(Comparator<T> cmp) {
        ArrayList<Boolean> bst = new ArrayList<>();
        Stack<BinaryTree<T>> s = new Stack<>();
        s.push(this);
        while (!s.isEmpty()) {
            BinaryTree<T> arbol = s.pop();
            if (arbol.getLeft() != null) {
                bst.add(cmp.compare(arbol.getRoot(), arbol.getLeft().getRoot()) > 0);
                s.push(arbol.getLeft());
            }
            if (arbol.getRight() != null) {
                bst.add(cmp.compare(arbol.getRoot(), arbol.getRight().getRoot()) < 0);
                s.push(arbol.getRight());
            }
        }
        return !bst.contains(false) && !bst.isEmpty();
    }

    public List<T> nodesAtLevel(int level) {
        int niv = 0;
        ArrayList<T> nodos = new ArrayList<>();
        Map<Integer, List<T>> levels = new HashMap<>();
        Set<Integer> keys = levels.keySet();
        if (isEmpty()) {
            return null;
        }
        nodos.add(this.getRoot());
        if (this.getLeft() != null) {
            niv++;
            nodos.addAll(this.getLeft().nodesAtLevel(level));
            levels.put(niv, nodos);
        }
        if (this.getRight() != null) {
            niv++;
            nodos.addAll(this.getRight().nodesAtLevel(level));
            levels.put(niv, nodos);
        }
        Iterator<Integer> it = keys.iterator();
        while (it.hasNext()) {
            System.out.println("Comienzo");
            System.out.println(it.next());
            System.out.println("Final");
        }
        return nodos;
    }
}
