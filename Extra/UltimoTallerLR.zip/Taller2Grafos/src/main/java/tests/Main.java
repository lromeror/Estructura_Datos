package tests;

import java.util.Comparator;
import tda.Graph;
import tda.GraphAL;

public class Main {
    public static void main(String[] args) throws Exception {
        
        Comparator<String> cmpVertices = (s1, s2) -> {
            return s1.compareTo(s2);
        };
        
        Comparator<String> cmpEdges = (s1, s2) -> {
            return s1.compareTo(s2);
        };
        
        Graph<String, String> grafo = new GraphAL<>(true, cmpVertices, cmpEdges);

        grafo.addVertex("V1");
        grafo.addVertex("V2");
        grafo.addVertex("V3");
        grafo.addVertex("V4");
        grafo.addVertex("V5");
        grafo.addVertex("V6");

        grafo.connect("V1", "V2", 3, null);
        grafo.connect("V1", "V3", 4, null);
        grafo.connect("V1", "V5", 8, null);
        grafo.connect("V2", "V5", 5, null);
        grafo.connect("V3", "V5", 3, null);
        grafo.connect("V5", "V4", 7, null);
        grafo.connect("V5", "V6", 3, null);
        grafo.connect("V6", "V4", 2, null);
        
        
        Graph<String, String> grafo2 = new GraphAL<>(true, cmpVertices, cmpEdges);

        grafo2.addVertex("A");
        grafo2.addVertex("B");
        grafo2.addVertex("C");
        grafo2.addVertex("E");
        grafo2.addVertex("F");
        grafo2.addVertex("D");

        grafo2.connect("A", "B", 3, null);
        grafo2.connect("A", "E", 4, null);
        grafo2.connect("A", "C", 8, null);
        grafo2.connect("B", "E", 5, null);
        grafo2.connect("C", "E", 3, null);
        grafo2.connect("E", "F", 7, null);
        grafo2.connect("E", "D", 3, null);
        grafo2.connect("F", "D", 2, null);
        
       grafo2.dijkstra("A", "D");
        
    
       
    }
}
