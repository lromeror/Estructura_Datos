package tda;

import java.util.LinkedList;
import java.util.List;

class Vertex<V, E> {

    private V content;
    private List<Edge<E, V>> edges;
    private Vertex<V,E> predecesor;
    private int distance;

    public Vertex<V, E> getPredecesor() {
        return predecesor;
    }

    public void setPredecesor(Vertex<V, E> predecesor) {
        this.predecesor = predecesor;
    }
    private boolean isVisited;
    private int cummulativeDistance;

    public boolean isIsVisited() {
        return isVisited;
    }

    public int getCummulativeDistance() {
        return cummulativeDistance;
    }

    public void setCummulativeDistance(int cummulativeDistance) {
        this.cummulativeDistance = cummulativeDistance;
    }

    public void setIsVisited(boolean isVisited) {
        this.isVisited = isVisited;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public Vertex(V content) {
        this.content = content;
        this.edges = new LinkedList<>();
    }

    public V getContent() {
        return content;
    }

    public void setContent(V content) {
        this.content = content;
    }

    public List<Edge<E, V>> getEdges() {
        return edges;
    }

    public void setEdges(List<Edge<E, V>> edges) {
        this.edges = edges;
    }

    @Override
    public String toString() {
        return content.toString();
    }

}
