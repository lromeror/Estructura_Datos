package model;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Util {
    
    public static <T> List<T> obtenerSubcoleccionAleatoria(List<T> coleccionOriginal, int tamanoSubcoleccion) {
        if (coleccionOriginal == null || coleccionOriginal.isEmpty() || tamanoSubcoleccion <= 0) {
            throw new IllegalArgumentException("La colección original debe contener elementos y el tamaño de la subcolección debe ser mayor que cero.");
        }

        // Copia la colección original para no modificar la original
        List<T> copiaColeccion = new LinkedList<>(coleccionOriginal);

        // Mezcla la copia de la colección original para obtener elementos aleatorios
        Collections.shuffle(copiaColeccion);

        // Obtiene la subcolección del tamaño deseado
        int tamanoReal = Math.min(tamanoSubcoleccion, copiaColeccion.size());
        return copiaColeccion.subList(0, tamanoReal);
    }

}
