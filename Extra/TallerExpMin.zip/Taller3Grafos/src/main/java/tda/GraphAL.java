package tda;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;

public class GraphAL<V, E> implements Graph<V, E> {

    private List<Vertex> vertices;
    private boolean isDirected;
    private Comparator<V> cmpVertices;
    private Comparator<E> cmpEdges;

    public GraphAL(boolean isDirected, Comparator<V> cmpVertices, Comparator<E> cmpEdges) {
        this.isDirected = isDirected;
        this.cmpVertices = cmpVertices;
        this.cmpEdges = cmpEdges;
        this.vertices = new LinkedList<>();
    }

    @Override
    public boolean addVertex(V content) {
        Vertex<V, E> newVertex = new Vertex<>(content);
        return (content == null || this.hasVertex(content)) ? false : vertices.add(newVertex);
    }

    @Override
    public boolean hasVertex(V content) {
        for (Vertex<V, E> v : vertices) {
            if (this.cmpVertices.compare(content, v.getContent()) == 0) {
                return true;
            }
        }
        return false;
    }

    private Vertex<V, E> findVertex(V content) {
        for (Vertex<V, E> v : vertices) {
            if (this.cmpVertices.compare(content, v.getContent()) == 0) {
                return v;
            }
        }
        return null;
    }

    @Override
    public boolean removeVertex(V content) {
        if (content == null) {
            return false;
        }
        Vertex<V, E> v = findVertex(content);
        if (v == null) {
            return false;
        }
        for (Vertex<V, E> vertex : vertices) {
            Iterator<Edge<E, V>> edgesIterator = vertex.getEdges().iterator();
            while (edgesIterator.hasNext()) {
                Edge<E, V> currentEdge = edgesIterator.next();
                Vertex<V, E> currentSource = currentEdge.getSource();
                Vertex<V, E> currentTarget = currentEdge.getTarget();
                if (this.cmpVertices.compare(currentSource.getContent(), v.getContent()) == 0
                        || this.cmpVertices.compare(currentTarget.getContent(), v.getContent()) == 0) {
                    edgesIterator.remove();
                }
            }
        }

        v.setContent(null);
        v.setEdges(null);
        vertices.remove(v);
        return true;

    }

    @Override
    public boolean connect(V source, V target) {
        return connect(source, source, 0, null);
    }

    @Override
    public boolean connect(V source, V target, int weight) {
        return connect(source, source, weight, null);
    }

    @Override
    public boolean connect(V source, V target, int weight, E metadata) {
        if (source == null || target == null) {
            return false;
        }

        Vertex<V, E> vSource = findVertex(source);
        Vertex<V, E> vTarget = findVertex(target);

        if (vSource == null || vTarget == null) {
            return false;
        }

        Edge<E, V> e = new Edge<>(vSource, vTarget, weight, metadata);

        vSource.getEdges().add(e);
        if (!this.isDirected) {
            Edge<E, V> e1 = new Edge<>(vTarget, vSource, weight, metadata);
            vTarget.getEdges().add(e1);
        }
        return true;
    }

    @Override
    public boolean removeEdge(V source, V target) {
        if (source == null || target == null) {
            return false;
        }
        Vertex<V, E> vSource = findVertex(source);
        Vertex<V, E> vTarget = findVertex(target);
        if (vSource == null || vTarget == null) {
            return false;
        }
        List<Edge<E, V>> edges = vSource.getEdges();
        Iterator<Edge<E, V>> edgesIterator = edges.iterator();
        while (edgesIterator.hasNext()) {
            Edge<E, V> e = edgesIterator.next();
            if (this.cmpVertices.compare(e.getTarget().getContent(), vTarget.getContent()) == 0) {
                edgesIterator.remove();
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder v = new StringBuilder();
        v.append(" vertices = {");

        StringBuilder a = new StringBuilder();
        a.append(" edges = {");

        for (Vertex<V, E> vertex : vertices) {
            v.append(vertex.getContent());
            v.append(", ");
            for (Edge<E, V> e : vertex.getEdges()) {
                a.append(e.toString());
                a.append(", ");
            }
        }
        if (!vertices.isEmpty()) {
            v.delete(v.length() - 2, v.length());
        }
        if (a.length() > 4) {
            a.delete(a.length() - 2, a.length());
        }

        v.append("}");
        a.append("}");
        return v.toString() + "\n" + a.toString();
    }

    @Override
    public List<V> breadthTraversal(V start) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<V> depthTraversal(V start) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void ChangeVisit() {
        for (Vertex<V, E> v : vertices) {
            v.setVisited(false);

        }
    }

    public GraphAL<V, E> Kruskal() {
        if (isDirected) {
            return null;
        }
        if (vertices.size() < 3) {
            return null;
        }
        GraphAL<V, E> TreeExpan = getCopy();
        for (Vertex<V, E> vert : TreeExpan.vertices) {
            vert.setEdges(new LinkedList<>());
        }
        Comparator<Edge<E, V>> cmpEdge = (Edge<E, V> e1, Edge<E, V> e2) -> {
            return Integer.compare(e1.getWeight(), e2.getWeight());
        };
        Queue<Edge<E, V>> todaAris = new PriorityQueue<>(cmpEdge);
        for (Vertex<V, E> vertex : vertices) {
            for (Edge<E, V> aris : vertex.getEdges()) {
                todaAris.offer(aris);
            }
        }
        int arist = vertices.size() - 1;
        while (!todaAris.isEmpty() && arist > 0) {
            Edge<E, V> arisAct = todaAris.poll();
            V source = arisAct.getSource().getContent();
            V target = arisAct.getTarget().getContent();
            if (!TreeExpan.ExpansionConect(source, target)) {
                TreeExpan.connect(source, target, arisAct.getWeight(), arisAct.getMetadata());
                arist--;
            }
        }
        return TreeExpan;
    }

    private boolean ExpansionConect(V start, V end) {
        ChangeVisit();
        Vertex<V, E> VertexStart = findVertex(start);
        Vertex<V, E> VertexEnd = findVertex(end);
        if (VertexStart == null || VertexEnd == null || VertexStart.getEdges().isEmpty() || VertexEnd.getEdges().isEmpty()) {
            return false;
        }
        Stack<Vertex<V, E>> pilaVert = new Stack<>();
        pilaVert.push(VertexStart);
        while (!pilaVert.isEmpty()) {
            Vertex<V, E> actualVert = pilaVert.pop();
            actualVert.setVisited(true);
            if (cmpVertices.compare(actualVert.getContent(), end) == 0) {
                ChangeVisit();
                return true;
            }
            if (!actualVert.getEdges().isEmpty()) {
                for (Edge<E, V> aris : actualVert.getEdges()) {
                    Vertex<V, E> VertDesti = aris.getTarget();
                    if (!VertDesti.isVisited()) {
                        pilaVert.push(VertDesti);
                    }
                }
            }
        }
        ChangeVisit();
        return false;
    }

    private GraphAL<V, E> getCopy() {
        GraphAL<V, E> gradCopy = new GraphAL<>(this.isDirected, this.cmpVertices, this.cmpEdges);
        for (Vertex<V, E> vertex : vertices) {
            gradCopy.addVertex(vertex.getContent());
        }
        for (Vertex<V, E> Vertex : vertices) {
            for (Edge<E, V> aris : Vertex.getEdges()) {
                V start = aris.getSource().getContent();
                V end = aris.getTarget().getContent();
                gradCopy.connect(start, end, aris.getWeight(), aris.getMetadata());
            }
        }
        return gradCopy;
    }

    private List<Edge<E, V>> AristaSinRepeticion() {
        List<Edge<E, V>> aristas = new LinkedList<>();
        for (Vertex<V, E> vert : Kruskal().vertices) {
            for (Edge<E, V> ar : vert.getEdges()) {
                if (!ExistAris(aristas, ar)) {
                    aristas.add(ar);
                }
            }
        }
        return aristas;
    }

    private boolean ExistAris(List<Edge<E, V>> listEdge, Edge<E, V> aris) {
        for (Edge<E, V> edg : listEdge) {
            if (this.cmpVertices.compare(edg.getSource().getContent(), aris.getTarget().getContent()) == 0
                    && this.cmpVertices.compare(edg.getTarget().getContent(), aris.getSource().getContent()) == 0
                    && Integer.compare(edg.getWeight(), aris.getWeight()) == 0) {
                return true;
            }
        }
        return false;
    }

    public int CostoExpansion() {
        int costoExpansion = 0;
        for (Edge<E, V> arista : AristaSinRepeticion()) {
            costoExpansion = costoExpansion + arista.getWeight();
        }
        return costoExpansion;
    }

    public void ConexionesTree() {
        for (Edge<E, V> arista : AristaSinRepeticion()) {
            System.out.println("Vertice: " + arista.getSource() + " ----- " + arista.getTarget() + ". Costo Arista: " + arista.getWeight());
        }
    }

}
