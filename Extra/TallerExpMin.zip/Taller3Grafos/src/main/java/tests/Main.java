package tests;

import java.util.Comparator;
import tda.Graph;
import tda.GraphAL;

public class Main {

    public static void main(String[] args) {

        Comparator<String> cmpVertices = (s1, s2) -> {
            return s1.compareTo(s2);
        };

        Comparator<Integer> cmpEdges = (s1, s2) -> {
            return s1 - s2;
        };
        Comparator<String> cmpVert = (s1, s2) -> {
            return s1.compareTo(s2);
        };
        // El grafo mostrado a continuación es solo un ejemplo.
        // Siga las instrucciones del documento para instanciar su propio grafo

        Graph<String, Integer> grafo = new GraphAL<>(false, cmpVert, cmpEdges);
        grafo.addVertex("Ecuador");
        grafo.addVertex("Colombia");
        grafo.addVertex("Argentina");
        grafo.addVertex("USA");
        grafo.addVertex("Venezuela");
        grafo.addVertex("Brasil");
        grafo.addVertex("Uruguay");
        grafo.connect("Ecuador", "Colombia", 1, null);
        grafo.connect("Ecuador", "USA", 4, null);
        grafo.connect("Colombia", "Argentina", 2, null);
        grafo.connect("Colombia", "Venezuela", 4, null);
        grafo.connect("Colombia", "USA", 6, null);
        grafo.connect("Argentina", "Brasil", 6, null);
        grafo.connect("Argentina", "Venezuela", 5, null);
        grafo.connect("USA", "Venezuela", 3, null);
        grafo.connect("USA", "Uruguay", 4, null);
        grafo.connect("Venezuela", "Uruguay", 7, null);
        grafo.connect("Venezuela", "Brasil", 8, null);
        grafo.connect("Brasil", "Uruguay", 3, null);
        
        
        System.out.println("Arbol de Expansion Minima:");
        System.out.println("Al imprimir el grafo nos dara el arbol pero en ambas direccion porque es un Grafo no dirigido\n");
        System.out.println(grafo.Kruskal() + "\n");
        System.out.print("Costos de Expansion Minima: ");
        System.out.println(grafo.CostoExpansion() + "\n");
        System.out.println("Conexiones del Arbol de Expansion Minima sin Repeticiones");
        grafo.ConexionesTree();
    }
}
